"""
This module deals with making images (np arrays). It provides drawing
methods that are difficult to do with the existing Python libraries.
"""

import numpy as np
import cupy as cp

def blit(im1, im2, pos=None, mask=None, ismask=False):
    """ Blit an image over another.
    
    Blits ``im1`` on ``im2`` as position ``pos=(x,y)``, using the
    ``mask`` if provided. If ``im1`` and ``im2`` are mask pictures
    (2D float arrays) then ``ismask`` must be ``True``.
    """
    if pos is None:
        pos = [0, 0]

    # Convert all inputs to cupy arrays if they are not already
    im1 = cp.asarray(im1)
    im2 = cp.asarray(im2)
    if mask is not None:
        mask = cp.asarray(mask)

    # xp1, yp1, xp2, yp2 = blit area on im2
    # x1, y1, x2, y2 = area of im1 to blit on im2
    xp, yp = pos
    x1 = max(0, -xp)
    y1 = max(0, -yp)
    h1, w1 = im1.shape[:2]
    h2, w2 = im2.shape[:2]
    xp2 = min(w2, xp + w1)
    yp2 = min(h2, yp + h1)
    x2 = min(w1, w2 - xp)
    y2 = min(h1, h2 - yp)
    xp1 = max(0, xp)
    yp1 = max(0, yp)

    if (xp1 >= xp2) or (yp1 >= yp2):
        return im2

    blitted = im1[y1:y2, x1:x2]

    new_im2 = cp.copy(im2)

    if mask is None:
        new_im2[yp1:yp2, xp1:xp2] = blitted
    else:
        mask = mask[y1:y2, x1:x2]
        if len(im1.shape) == 3:
            mask = cp.dstack(3 * [mask])
        blit_region = new_im2[yp1:yp2, xp1:xp2]
        new_im2[yp1:yp2, xp1:xp2] = (1.0 * mask * blitted + (1.0 - mask) * blit_region)
    
    return new_im2.astype('uint8') if (not ismask) else new_im2



def color_gradient(size, p1, p2=None, vector=None, r=None, col1=0, col2=1.0,
                   shape='linear', offset=0):
    w, h = size
    
    col1 = cp.array(col1).astype(float)
    col2 = cp.array(col2).astype(float)
    
    if shape == 'bilinear':
        if vector is None:
            vector = cp.array(p2) - cp.array(p1)
        
        m1, m2 = [ color_gradient(size, p1, vector=v, col1=1.0, col2=0,
                                  shape='linear', offset=offset)
                   for v in [vector, -vector]]
        
        arr = cp.maximum(m1, m2)
        if col1.size > 1:
            arr = cp.dstack(3 * [arr])
        return arr * col1 + (1 - arr) * col2
    
    p1 = cp.array(p1[::-1]).astype(float)
    
    if vector is None and p2:
        p2 = cp.array(p2[::-1])
        vector = p2 - p1
    else:
        vector = cp.array(vector[::-1])
        p2 = p1 + vector
    
    if vector:
        norm = cp.linalg.norm(vector)
    
    M = cp.dstack(cp.meshgrid(range(w), range(h))[::-1]).astype(float)
    
    if shape == 'linear':
        
        n_vec = vector / norm**2
        
        p1 = p1 + offset * vector
        arr = (M - p1).dot(n_vec) / (1 - offset)
        arr = cp.minimum(1, cp.maximum(0, arr))
        if col1.size > 1:
            arr = cp.dstack(3 * [arr])
        return arr * col1 + (1 - arr) * col2
    
    elif shape == 'radial':
        if r is None:
            r = norm

        if r == 0:
            arr = cp.ones((h, w))
        else:
            arr = (cp.sqrt(((M - p1) ** 2).sum(axis=2))) - offset * r
            arr = arr / ((1 - offset) * r)
            arr = cp.minimum(1.0, cp.maximum(0, arr))
            
        if col1.size > 1:
            arr = cp.dstack(3 * [arr])
        return (1 - arr) * col1 + arr * col2
                

def color_split(size,x=None,y=None,p1=None,p2=None,vector=None,
                             col1=0,col2=1.0, grad_width=0):
    """Make an image splitted in 2 colored regions.
    
    Returns an array of size ``size`` divided in two regions called 1 and
    2 in wht follows, and which will have colors col& and col2
    respectively.
    
    Parameters
    -----------
    
    x: (int)
        If provided, the image is splitted horizontally in x, the left
        region being region 1.
            
    y: (int)
        If provided, the image is splitted vertically in y, the top region
        being region 1.
    
    p1,p2:
        Positions (x1,y1),(x2,y2) in pixels, where the numbers can be
        floats. Region 1 is defined as the whole region on the left when
        going from ``p1`` to ``p2``.
    
    p1, vector:
        ``p1`` is (x1,y1) and vector (v1,v2), where the numbers can be
        floats. Region 1 is then the region on the left when starting
        in position ``p1`` and going in the direction given by ``vector``.
         
    gradient_width
        If not zero, the split is not sharp, but gradual over a region of
        width ``gradient_width`` (in pixels). This is preferable in many
        situations (for instance for antialiasing). 
     
    
    Examples
    ---------
    
    >>> size = [200,200]
    >>> # an image with all pixels with x<50 =0, the others =1
    >>> color_split(size, x=50, col1=0, col2=1)
    >>> # an image with all pixels with y<50 red, the others green
    >>> color_split(size, x=50, col1=[255,0,0], col2=[0,255,0])
    >>> # An image splitted along an arbitrary line (see below) 
    >>> color_split(size, p1=[20,50], p2=[25,70] col1=0, col2=1)
            
    """
    
    if grad_width or ( (x is None) and (y is None)):
        if p2 is not None:
            vector = (np.array(p2) - np.array(p1))
        elif x is not None:
            vector = np.array([0,-1.0])
            p1 = np.array([x, 0])
        elif y is not None:
            vector = np.array([1.0, 0.0])
            p1 = np.array([0,y])

        x,y = vector
        vector = np.array([y,-x]).astype('float')
        norm = np.linalg.norm(vector)
        vector = max(0.1, grad_width) * vector / norm
        return color_gradient(size,p1,vector=vector,
                              col1 = col1, col2 = col2, shape='linear')
    else:
        w, h = size
        shape = (h, w) if np.isscalar(col1) else (h, w, len(col1))
        arr = np.zeros(shape)
        if x:
            arr[:,:x] = col1
            arr[:,x:] = col2
        elif y:
            arr[:y] = col1
            arr[y:] = col2
        return arr
     
    # if we are here, it means we didn't exit with a proper 'return'
    print( "Arguments in color_split not understood !" )
    raise
        
def circle(screensize, center, radius, col1=1.0, col2=0, blur=1):
    """ Draw an image with a circle.
    
    Draws a circle of color ``col1``, on a background of color ``col2``,
    on a screen of size ``screensize`` at the position ``center=(x,y)``,
    with a radius ``radius`` but slightly blurred on the border by ``blur``
    pixels
    """
    offset = 1.0*(radius-blur)/radius if radius else 0              
    return color_gradient(screensize,p1=center,r=radius, col1=col1,
                          col2=col2, shape='radial', offset=offset)
